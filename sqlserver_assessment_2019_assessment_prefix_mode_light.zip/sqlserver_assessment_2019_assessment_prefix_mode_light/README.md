# Kit de Assessment – BD_AUDITORIA (SQL Server 2019)
## Novidades
- Orquestrador com `@mode = 'LIGHT' | 'FULL'` (padrão FULL).
- IndexHealth leve: `LIMITED`, `page_count >= 5000`, `WAITFOR 1s` entre DBs.
- Hotfixes prévios: SERVERPROPERTY casts, AGs, XE, AgentJobs datas nulas, WaitStats COALESCE, HEAP no IndexHealth.
