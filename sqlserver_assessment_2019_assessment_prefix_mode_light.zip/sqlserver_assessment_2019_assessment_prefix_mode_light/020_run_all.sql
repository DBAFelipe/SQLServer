-- 020_run_all.sql
USE BD_AUDITORIA;
GO
EXEC dbo.usp_assessment_Run_All @mode = 'LIGHT';
GO
SELECT * FROM dbo.v_assessment_LastRun;
