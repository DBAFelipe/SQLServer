/* 000_install.sql (modo LIGHT/FULL + IndexHealth leve) */
SET NOCOUNT ON;
IF DB_ID(N'BD_AUDITORIA') IS NULL
BEGIN
    THROW 51000, 'Banco BD_AUDITORIA não encontrado. Crie-o antes de rodar este script.', 1;
END
GO
USE BD_AUDITORIA;
GO
-- ===== Tabelas
IF OBJECT_ID('dbo.assessment_Run','U') IS NULL
CREATE TABLE dbo.assessment_Run(
    run_id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    server_name SYSNAME NOT NULL,
    start_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    end_time   DATETIME2(0) NULL,
    notes NVARCHAR(4000) NULL
);
GO
CREATE OR ALTER VIEW dbo.v_assessment_LastRun AS
SELECT TOP(1) * FROM dbo.assessment_Run ORDER BY start_time DESC;
GO
IF OBJECT_ID('dbo.assessment_InstanceOverview','U') IS NULL
CREATE TABLE dbo.assessment_InstanceOverview(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    server_name SYSNAME NULL,
    machine_name SYSNAME NULL,
    edition NVARCHAR(128) NULL,
    product_version NVARCHAR(128) NULL,
    product_level NVARCHAR(128) NULL,
    product_update_level NVARCHAR(128) NULL,
    collation NVARCHAR(128) NULL,
    is_hadr_enabled BIT NULL,
    sqlserver_start_time DATETIME2 NULL
);
GO
IF OBJECT_ID('dbo.assessment_ServerConfig','U') IS NULL
CREATE TABLE dbo.assessment_ServerConfig(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    name SYSNAME,
    value_in_use SQL_VARIANT,
    value SQL_VARIANT,
    description NVARCHAR(2048)
);
GO
IF OBJECT_ID('dbo.assessment_Hardware','U') IS NULL
CREATE TABLE dbo.assessment_Hardware(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    cpu_count INT, hyperthread_ratio INT, scheduler_count INT, numa_node_count INT,
    physical_memory_gb DECIMAL(18,2), sqlserver_start_time DATETIME2
);
GO
IF OBJECT_ID('dbo.assessment_Databases','U') IS NULL
CREATE TABLE dbo.assessment_Databases(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    database_id INT, name SYSNAME, state_desc NVARCHAR(60), owner_name SYSNAME,
    create_date DATETIME, compatibility_level INT, collation_name SYSNAME,
    page_verify_option_desc NVARCHAR(60), recovery_model_desc NVARCHAR(60),
    user_access_desc NVARCHAR(60), is_auto_update_stats_on BIT,
    is_auto_update_stats_async_on BIT, is_auto_create_stats_on BIT,
    is_encrypted BIT, containment NVARCHAR(60)
);
GO
IF OBJECT_ID('dbo.assessment_Files','U') IS NULL
CREATE TABLE dbo.assessment_Files(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    database_name SYSNAME, file_id INT, type_desc NVARCHAR(60), name SYSNAME, physical_name NVARCHAR(260),
    size_mb DECIMAL(18,2), growth_desc NVARCHAR(50), is_percent_growth BIT, max_size_mb DECIMAL(18,2) NULL
);
GO
IF OBJECT_ID('dbo.assessment_Backups','U') IS NULL
CREATE TABLE dbo.assessment_Backups(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    database_name SYSNAME, type CHAR(1),
    backup_start_date DATETIME, backup_finish_date DATETIME,
    backup_size_mb DECIMAL(18,2)
);
GO
IF OBJECT_ID('dbo.assessment_LastBackupAge','U') IS NULL
CREATE TABLE dbo.assessment_LastBackupAge(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    database_name SYSNAME, last_full DATETIME, last_log DATETIME,
    hours_since_full INT, minutes_since_log INT
);
GO
IF OBJECT_ID('dbo.assessment_LastCheckDB','U') IS NULL
CREATE TABLE dbo.assessment_LastCheckDB(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    database_name SYSNAME, last_checkdb_end DATETIME NULL
);
GO
IF OBJECT_ID('dbo.assessment_AgentJobs','U') IS NULL
CREATE TABLE dbo.assessment_AgentJobs(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    job_id UNIQUEIDENTIFIER, name SYSNAME, enabled BIT, owner_name SYSNAME,
    schedule_name SYSNAME NULL, schedule_enabled BIT NULL,
    next_run DATETIME NULL, last_run DATETIME NULL, last_run_outcome NVARCHAR(30) NULL
);
GO
IF OBJECT_ID('dbo.assessment_WaitStats','U') IS NULL
CREATE TABLE dbo.assessment_WaitStats(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    wait_type NVARCHAR(120), waiting_tasks_count BIGINT,
    wait_time_ms BIGINT, signal_wait_time_ms BIGINT, resource_wait_ms BIGINT, pct DECIMAL(5,2)
);
GO
IF OBJECT_ID('dbo.assessment_TopQueriesCpu','U') IS NULL
CREATE TABLE dbo.assessment_TopQueriesCpu(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    total_worker_time_ms BIGINT, execution_count BIGINT, avg_cpu_ms BIGINT,
    last_execution_time DATETIME2,
    obj_name NVARCHAR(512) NULL, query_text NVARCHAR(MAX) NULL
);
GO
IF OBJECT_ID('dbo.assessment_TopQueriesReads','U') IS NULL
CREATE TABLE dbo.assessment_TopQueriesReads(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    total_logical_reads BIGINT, avg_logical_reads BIGINT,
    last_execution_time DATETIME2, query_text NVARCHAR(MAX) NULL
);
GO
IF OBJECT_ID('dbo.assessment_IndexHealth','U') IS NULL
CREATE TABLE dbo.assessment_IndexHealth(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    database_name SYSNAME, schema_name SYSNAME, table_name SYSNAME, index_name SYSNAME,
    index_type_desc NVARCHAR(60), avg_fragmentation_in_percent DECIMAL(6,2), page_count INT
);
GO
IF OBJECT_ID('dbo.assessment_StatsStaleness','U') IS NULL
CREATE TABLE dbo.assessment_StatsStaleness(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    database_name SYSNAME, schema_name SYSNAME, table_name SYSNAME,
    stats_name SYSNAME, last_updated DATETIME NULL, rows BIGINT NULL, modification_counter BIGINT NULL
);
GO
IF OBJECT_ID('dbo.assessment_TempdbFiles','U') IS NULL
CREATE TABLE dbo.assessment_TempdbFiles(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    name SYSNAME, file_id INT, type_desc NVARCHAR(60), physical_name NVARCHAR(260),
    size_mb DECIMAL(18,2), growth_desc NVARCHAR(50), is_percent_growth BIT
);
GO
IF OBJECT_ID('dbo.assessment_TraceFlags','U') IS NULL
CREATE TABLE dbo.assessment_TraceFlags(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    TraceFlag INT, Status INT, Global INT, Session INT
);
GO
IF OBJECT_ID('dbo.assessment_SecurityLogins','U') IS NULL
CREATE TABLE dbo.assessment_SecurityLogins(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    name SYSNAME, type_desc NVARCHAR(60), is_disabled BIT, create_date DATETIME,
    default_database_name SYSNAME
);
GO
IF OBJECT_ID('dbo.assessment_SecurityServerRoles','U') IS NULL
CREATE TABLE dbo.assessment_SecurityServerRoles(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    role_name SYSNAME, member_name SYSNAME
);
GO
IF OBJECT_ID('dbo.assessment_AGReplicas','U') IS NULL
CREATE TABLE dbo.assessment_AGReplicas(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    ag_name SYSNAME, group_id UNIQUEIDENTIFIER, cluster_type_desc NVARCHAR(60),
    automation_seeding_mode_desc NVARCHAR(60),
    replica_server_name SYSNAME, role_desc NVARCHAR(60),
    operational_state_desc NVARCHAR(60), synchronization_health_desc NVARCHAR(60),
    database_name SYSNAME NULL, synchronization_state_desc NVARCHAR(60) NULL
);
GO
IF OBJECT_ID('dbo.assessment_LinkedServers','U') IS NULL
CREATE TABLE dbo.assessment_LinkedServers(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    name SYSNAME, product NVARCHAR(128), provider NVARCHAR(128),
    data_source NVARCHAR(4000), is_rpc_out_enabled BIT, is_data_access_enabled BIT
);
GO
IF OBJECT_ID('dbo.assessment_Endpoints','U') IS NULL
CREATE TABLE dbo.assessment_Endpoints(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    name SYSNAME, type_desc NVARCHAR(60), state_desc NVARCHAR(60),
    protocol_desc NVARCHAR(60), port INT, is_admin_endpoint BIT
);
GO
IF OBJECT_ID('dbo.assessment_XESessions','U') IS NULL
CREATE TABLE dbo.assessment_XESessions(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    name SYSNAME, starts_on_server_startup BIT, is_started BIT
);
GO
IF OBJECT_ID('dbo.assessment_ModelMsdb','U') IS NULL
CREATE TABLE dbo.assessment_ModelMsdb(
    run_id UNIQUEIDENTIFIER NOT NULL,
    collection_time DATETIME2(0) NOT NULL DEFAULT SYSDATETIME(),
    db SYSNAME, name SYSNAME, recovery_model_desc NVARCHAR(60),
    page_verify_option_desc NVARCHAR(60), is_auto_shrink_on BIT, is_auto_close_on BIT
);
GO

-- ===== Procedures =====
CREATE OR ALTER PROCEDURE dbo.usp_assessment_NewRun @run_id UNIQUEIDENTIFIER OUTPUT AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @srv SYSNAME = CONVERT(sysname, SERVERPROPERTY('ServerName'));
    SET @run_id = NEWID();
    INSERT INTO dbo.assessment_Run(run_id, server_name, start_time) VALUES(@run_id, @srv, SYSDATETIME());
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_EndRun @run_id UNIQUEIDENTIFIER AS
BEGIN
    UPDATE dbo.assessment_Run SET end_time = SYSDATETIME() WHERE run_id = @run_id;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_InstanceOverview @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_InstanceOverview
        (run_id, server_name, machine_name, edition, product_version, product_level, product_update_level, collation, is_hadr_enabled, sqlserver_start_time)
    SELECT @run_id, CONVERT(nvarchar(128), @@SERVERNAME), CONVERT(nvarchar(128), SERVERPROPERTY('MachineName')),
           CONVERT(nvarchar(128), SERVERPROPERTY('Edition')), CONVERT(nvarchar(128), SERVERPROPERTY('ProductVersion')),
           CONVERT(nvarchar(128), SERVERPROPERTY('ProductLevel')), CONVERT(nvarchar(128), SERVERPROPERTY('ProductUpdateLevel')),
           CONVERT(nvarchar(128), SERVERPROPERTY('Collation')), CONVERT(bit, SERVERPROPERTY('IsHadrEnabled')), si.sqlserver_start_time
    FROM sys.dm_os_sys_info AS si;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_ServerConfig @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_ServerConfig(run_id, name, value_in_use, value, description)
    SELECT @run_id, name, value_in_use, value, description FROM sys.configurations;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_Hardware @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_Hardware(run_id, cpu_count, hyperthread_ratio, scheduler_count, numa_node_count, physical_memory_gb, sqlserver_start_time)
    SELECT @run_id, cpu_count, hyperthread_ratio, scheduler_count, numa_node_count, physical_memory_kb/1024.0/1024.0, sqlserver_start_time
    FROM sys.dm_os_sys_info;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_Databases @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_Databases(run_id, database_id, name, state_desc, owner_name, create_date, compatibility_level, collation_name, page_verify_option_desc, recovery_model_desc, user_access_desc, is_auto_update_stats_on, is_auto_update_stats_async_on, is_auto_create_stats_on, is_encrypted, containment)
    SELECT @run_id, db.database_id, db.name, db.state_desc, suser_sname(db.owner_sid),
           db.create_date, db.compatibility_level, db.collation_name, db.page_verify_option_desc,
           db.recovery_model_desc, db.user_access_desc, db.is_auto_update_stats_on,
           db.is_auto_update_stats_async_on, db.is_auto_create_stats_on, db.is_encrypted, db.containment_desc
    FROM sys.databases db;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_Files @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_Files(run_id, database_name, file_id, type_desc, name, physical_name, size_mb, growth_desc, is_percent_growth, max_size_mb)
    SELECT @run_id, db_name(mf.database_id), mf.file_id, mf.type_desc, mf.name, mf.physical_name,
           CONVERT(decimal(18,2), mf.size/128.0),
           CASE mf.is_percent_growth WHEN 1 THEN CONCAT(mf.growth, '%') ELSE CONCAT(mf.growth/128, ' MB') END,
           mf.is_percent_growth, CASE mf.max_size WHEN -1 THEN NULL ELSE mf.max_size/128.0 END
    FROM sys.master_files mf;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_Backups @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    WITH b AS (
        SELECT bs.database_name, bs.type, bs.backup_start_date, bs.backup_finish_date,
               bs.backup_size/1048576.0 AS backup_size_mb,
               DENSE_RANK() OVER (PARTITION BY bs.database_name, bs.type ORDER BY bs.backup_finish_date DESC) AS rn
        FROM msdb.dbo.backupset bs
    )
    INSERT INTO dbo.assessment_Backups(run_id, database_name, type, backup_start_date, backup_finish_date, backup_size_mb)
    SELECT @run_id, database_name, type, backup_start_date, backup_finish_date, backup_size_mb
    FROM b WHERE rn <= 3;

    WITH lastb AS (
        SELECT database_name,
               last_full = MAX(CASE WHEN type = 'D' THEN backup_finish_date END),
               last_log  = MAX(CASE WHEN type = 'L' THEN backup_finish_date END)
        FROM msdb.dbo.backupset
        GROUP BY database_name
    )
    INSERT INTO dbo.assessment_LastBackupAge(run_id, database_name, last_full, last_log, hours_since_full, minutes_since_log)
    SELECT @run_id, database_name, last_full, last_log,
           DATEDIFF(HOUR, last_full, SYSDATETIME()), DATEDIFF(MINUTE, last_log, SYSDATETIME())
    FROM lastb;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_LastCheckDB @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_LastCheckDB(run_id, database_name, last_checkdb_end)
    SELECT @run_id, d.name, NULL
    FROM sys.databases d;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_AgentJobs @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_AgentJobs
    (run_id, job_id, name, enabled, owner_name, schedule_name, schedule_enabled, next_run, last_run, last_run_outcome)
    SELECT @run_id, j.job_id, j.name, j.enabled, suser_sname(j.owner_sid),
           sch.name, sch.enabled,
           CASE WHEN js.next_run_date IS NULL OR js.next_run_date = 0 OR js.next_run_time IS NULL
                THEN NULL ELSE msdb.dbo.agent_datetime(js.next_run_date, js.next_run_time) END,
           CASE WHEN lr.run_date IS NULL OR lr.run_date = 0 OR lr.run_time IS NULL
                THEN NULL ELSE msdb.dbo.agent_datetime(lr.run_date, lr.run_time) END,
           CASE lr.run_status WHEN 0 THEN 'Failed' WHEN 1 THEN 'Succeeded' WHEN 2 THEN 'Retry' WHEN 3 THEN 'Canceled' ELSE 'Unknown' END
    FROM msdb.dbo.sysjobs AS j
    LEFT JOIN msdb.dbo.sysjobschedules AS js ON j.job_id = js.job_id
    LEFT JOIN msdb.dbo.sysschedules AS sch ON js.schedule_id = sch.schedule_id
    OUTER APPLY (SELECT TOP (1) h.run_date, h.run_time, h.run_status
                 FROM msdb.dbo.sysjobhistory AS h
                 WHERE h.job_id = j.job_id AND h.step_id = 0
                 ORDER BY h.instance_id DESC) AS lr;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_WaitStats @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    ;WITH waits AS (
        SELECT wait_type, waiting_tasks_count, wait_time_ms, signal_wait_time_ms,
               wait_time_ms - signal_wait_time_ms AS resource_wait_ms
        FROM sys.dm_os_wait_stats
        WHERE wait_type NOT LIKE 'SLEEP%'
          AND wait_type NOT IN ('BROKER_TASK_STOP','BROKER_TO_FLUSH','BROKER_EVENTHANDLER','XE_TIMER_EVENT','XE_DISPATCHER_WAIT','SQLTRACE_BUFFER_FLUSH','REQUEST_FOR_DEADLOCK_SEARCH','CLR_SEMAPHORE','LAZYWRITER_SLEEP','FT_IFTS_SCHEDULER_IDLE_WAIT','BROKER_TRANSMITTER','TRACEWRITE','LOGMGR_QUEUE','ONDEMAND_TASK_QUEUE','CHECKPOINT_QUEUE','DBMIRROR_EVENTS_QUEUE','DBMIRRORING_CMD','DIRTY_PAGE_POLL','HADR_FILESTREAM_IOMGR_IOCOMPLETION','HADR_WORK_QUEUE','SP_SERVER_DIAGNOSTICS_SLEEP')
    )
    INSERT INTO dbo.assessment_WaitStats(run_id, wait_type, waiting_tasks_count, wait_time_ms, signal_wait_time_ms, resource_wait_ms, pct)
    SELECT @run_id, wait_type, waiting_tasks_count, wait_time_ms, signal_wait_time_ms, resource_wait_ms,
           CAST(wait_time_ms * 100.0 / NULLIF(SUM(COALESCE(wait_time_ms,0)) OVER (), 0) AS DECIMAL(5,2))
    FROM waits;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_TopQueries @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_TopQueriesCpu(run_id, total_worker_time_ms, execution_count, avg_cpu_ms, last_execution_time, obj_name, query_text)
    SELECT TOP (25) @run_id, qs.total_worker_time/1000, qs.execution_count,
           (qs.total_worker_time/1000)/NULLIF(qs.execution_count,0),
           qs.last_execution_time,
           OBJECT_SCHEMA_NAME(st.objectid, st.dbid) + '.' + OBJECT_NAME(st.objectid, st.dbid),
           SUBSTRING(st.text, (qs.statement_start_offset/2)+1,
                              ((CASE qs.statement_end_offset WHEN -1 THEN DATALENGTH(st.text) ELSE qs.statement_end_offset END - qs.statement_start_offset)/2)+1)
    FROM sys.dm_exec_query_stats qs
    CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st
    ORDER BY qs.total_worker_time DESC;
    INSERT INTO dbo.assessment_TopQueriesReads(run_id, total_logical_reads, avg_logical_reads, last_execution_time, query_text)
    SELECT TOP (25) @run_id, qs.total_logical_reads, qs.total_logical_reads/NULLIF(qs.execution_count,0),
           qs.last_execution_time,
           SUBSTRING(st.text, (qs.statement_start_offset/2)+1,
                              ((CASE qs.statement_end_offset WHEN -1 THEN DATALENGTH(st.text) ELSE qs.statement_end_offset END - qs.statement_start_offset)/2)+1)
    FROM sys.dm_exec_query_stats qs
    CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st
    ORDER BY qs.total_logical_reads DESC;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_IndexHealth @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @db sysname;
    DECLARE c CURSOR LOCAL FAST_FORWARD FOR
        SELECT name FROM sys.databases WHERE state = 0 AND database_id > 4;
    OPEN c; FETCH NEXT FROM c INTO @db;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @sql nvarchar(max) = N'
        USE ' + QUOTENAME(@db) + N';
        INSERT INTO BD_AUDITORIA.dbo.assessment_IndexHealth
        (run_id, database_name, schema_name, table_name, index_name, index_type_desc, avg_fragmentation_in_percent, page_count)
        SELECT ''' + CONVERT(nvarchar(36), @run_id) + ''', DB_NAME(), OBJECT_SCHEMA_NAME(i.object_id), OBJECT_NAME(i.object_id),
               ISNULL(i.name, ''HEAP''), ips.index_type_desc, ips.avg_fragmentation_in_percent, ips.page_count
        FROM sys.indexes i
        CROSS APPLY sys.dm_db_index_physical_stats(DB_ID(), i.object_id, i.index_id, NULL, ''LIMITED'') ips
        WHERE ips.page_count >= 5000;';
        EXEC (@sql);
        WAITFOR DELAY '00:00:01';
        FETCH NEXT FROM c INTO @db;
    END
    CLOSE c; DEALLOCATE c;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_StatsStaleness @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @db sysname;
    DECLARE c CURSOR LOCAL FAST_FORWARD FOR
        SELECT name FROM sys.databases WHERE state = 0 AND database_id > 4;
    OPEN c; FETCH NEXT FROM c INTO @db;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @sql nvarchar(max) = N'
        USE ' + QUOTENAME(@db) + N';
        INSERT INTO BD_AUDITORIA.dbo.assessment_StatsStaleness(run_id, database_name, schema_name, table_name, stats_name, last_updated, rows, modification_counter)
        SELECT ''' + CONVERT(nvarchar(36), @run_id) + ''', DB_NAME(), OBJECT_SCHEMA_NAME(s.object_id), OBJECT_NAME(s.object_id),
               s.name, sp.last_updated, sp.rows, sp.modification_counter
        FROM sys.stats s
        OUTER APPLY sys.dm_db_stats_properties(s.object_id, s.stats_id) sp
        WHERE s.auto_created = 1 OR s.user_created = 1;';
        EXEC (@sql);
        WAITFOR DELAY '00:00:01';
        FETCH NEXT FROM c INTO @db;
    END
    CLOSE c; DEALLOCATE c;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_Tempdb @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_TempdbFiles(run_id, name, file_id, type_desc, physical_name, size_mb, growth_desc, is_percent_growth)
    SELECT @run_id, name, file_id, type_desc, physical_name, size/128.0,
           CASE is_percent_growth WHEN 1 THEN CONCAT(growth, '%') ELSE CONCAT(growth/128, ' MB') END, is_percent_growth
    FROM tempdb.sys.database_files;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_TraceFlags @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    CREATE TABLE #t(TraceFlag INT, Status INT, Global INT, Session INT);
    INSERT #t EXEC ('DBCC TRACESTATUS(-1) WITH NO_INFOMSGS');
    INSERT INTO dbo.assessment_TraceFlags(run_id, TraceFlag, Status, Global, Session)
    SELECT @run_id, TraceFlag, Status, Global, Session FROM #t;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_Security @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_SecurityLogins(run_id, name, type_desc, is_disabled, create_date, default_database_name)
    SELECT @run_id, name, type_desc, is_disabled, create_date, default_database_name
    FROM sys.server_principals
    WHERE type IN ('S','U','G') AND name NOT LIKE '##%';
    INSERT INTO dbo.assessment_SecurityServerRoles(run_id, role_name, member_name)
    SELECT @run_id, sp2.name, sp1.name
    FROM sys.server_role_members rm
    JOIN sys.server_principals sp1 ON rm.member_principal_id = sp1.principal_id
    JOIN sys.server_principals sp2 ON rm.role_principal_id = sp2.principal_id;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_AGs @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    IF SERVERPROPERTY('IsHadrEnabled') = 1
    BEGIN
        INSERT INTO dbo.assessment_AGReplicas(run_id, ag_name, group_id, cluster_type_desc, automation_seeding_mode_desc, replica_server_name, role_desc, operational_state_desc, synchronization_health_desc, database_name, synchronization_state_desc)
        SELECT @run_id, ag.name, ag.group_id, ag.cluster_type_desc, rl.seeding_mode_desc, rl.replica_server_name, rs.role_desc, rs.operational_state_desc, rs.synchronization_health_desc, d.name, dbcs.synchronization_state_desc
        FROM sys.availability_groups ag
        JOIN sys.availability_replicas rl ON ag.group_id = rl.group_id
        JOIN sys.dm_hadr_availability_replica_states rs ON rl.replica_id = rs.replica_id
        LEFT JOIN sys.dm_hadr_database_replica_states dbcs ON rs.replica_id = dbcs.replica_id
        LEFT JOIN master.sys.databases d ON dbcs.database_id = d.database_id;
    END
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_LinkedServers @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_LinkedServers(run_id, name, product, provider, data_source, is_rpc_out_enabled, is_data_access_enabled)
    SELECT @run_id, srv.name, srv.product, srv.provider, srv.data_source, srv.is_rpc_out_enabled, srv.is_data_access_enabled
    FROM sys.servers srv WHERE srv.server_id <> 0;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_Endpoints @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_Endpoints(run_id, name, type_desc, state_desc, protocol_desc, port, is_admin_endpoint)
    SELECT @run_id, name, type_desc, state_desc, protocol_desc, port, is_admin_endpoint
    FROM sys.tcp_endpoints;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_XESessions @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_XESessions(run_id, name, starts_on_server_startup, is_started)
    SELECT @run_id, ses.name, CAST(ses.startup_state AS bit), CAST(CASE WHEN dxs.name IS NULL THEN 0 ELSE 1 END AS bit)
    FROM sys.server_event_sessions AS ses
    LEFT JOIN sys.dm_xe_sessions AS dxs ON dxs.name = ses.name;
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Collect_ModelMsdb @run_id UNIQUEIDENTIFIER AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO dbo.assessment_ModelMsdb(run_id, db, name, recovery_model_desc, page_verify_option_desc, is_auto_shrink_on, is_auto_close_on)
    SELECT @run_id, 'model', name, recovery_model_desc, page_verify_option_desc, is_auto_shrink_on, is_auto_close_on
    FROM master.sys.databases WHERE name = 'model';
    INSERT INTO dbo.assessment_ModelMsdb(run_id, db, name, recovery_model_desc, page_verify_option_desc, is_auto_shrink_on, is_auto_close_on)
    SELECT @run_id, 'msdb', name, recovery_model_desc, page_verify_option_desc, is_auto_shrink_on, is_auto_close_on
    FROM master.sys.databases WHERE name = 'msdb';
END
GO
CREATE OR ALTER PROCEDURE dbo.usp_assessment_Run_All @mode VARCHAR(10) = 'FULL' AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @run UNIQUEIDENTIFIER;
    EXEC dbo.usp_assessment_NewRun @run_id = @run OUTPUT;
    BEGIN TRY
        EXEC dbo.usp_assessment_Collect_InstanceOverview @run;
        EXEC dbo.usp_assessment_Collect_ServerConfig    @run;
        EXEC dbo.usp_assessment_Collect_Hardware        @run;
        EXEC dbo.usp_assessment_Collect_Databases       @run;
        EXEC dbo.usp_assessment_Collect_Files           @run;
        EXEC dbo.usp_assessment_Collect_Backups         @run;
        EXEC dbo.usp_assessment_Collect_LastCheckDB     @run;
        EXEC dbo.usp_assessment_Collect_AgentJobs       @run;
        EXEC dbo.usp_assessment_Collect_WaitStats       @run;
        EXEC dbo.usp_assessment_Collect_TopQueries      @run;
        EXEC dbo.usp_assessment_Collect_Tempdb          @run;
        EXEC dbo.usp_assessment_Collect_TraceFlags      @run;
        EXEC dbo.usp_assessment_Collect_Security        @run;
        EXEC dbo.usp_assessment_Collect_AGs             @run;
        EXEC dbo.usp_assessment_Collect_LinkedServers   @run;
        EXEC dbo.usp_assessment_Collect_Endpoints       @run;
        EXEC dbo.usp_assessment_Collect_XESessions      @run;
        EXEC dbo.usp_assessment_Collect_ModelMsdb       @run;
        IF UPPER(@mode) = 'FULL'
        BEGIN
            EXEC dbo.usp_assessment_Collect_IndexHealth    @run;
            EXEC dbo.usp_assessment_Collect_StatsStaleness @run;
        END
    END TRY
    BEGIN CATCH
        UPDATE dbo.assessment_Run SET notes = CONCAT(ISNULL(notes,''),' | ERROR: ', ERROR_MESSAGE()) WHERE run_id = @run;
        THROW;
    END CATCH;
    EXEC dbo.usp_assessment_EndRun @run;
END
GO
